#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    printf("lama\n");
	return 0;
}
