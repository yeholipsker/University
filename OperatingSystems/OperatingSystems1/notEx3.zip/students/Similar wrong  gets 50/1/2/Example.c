#include <stdio.h>

int main()
{
	int n1, n2;
	printf("please enter two nUmbers\n");
	scanf ("%d %d",&n1, &n2);
	printf("%d", n1+n2);
}
